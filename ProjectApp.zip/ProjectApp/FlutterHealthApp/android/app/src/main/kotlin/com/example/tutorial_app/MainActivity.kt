package com.example.tutorial_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
