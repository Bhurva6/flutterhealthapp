import 'package:flutter/material.dart';
import 'NewPatients.dart';

class IndividualPatientDetails extends StatefulWidget {
  IndividualPatientDetails({
    this.name,
    this.slno,
    this.i,
    this.pulseMin,
  });
  final String name;
  final String slno;
  final int i;
  final String pulseMin;

  @override
  _IndividualPatientDetailsState createState() =>
      _IndividualPatientDetailsState();
}

class _IndividualPatientDetailsState extends State<IndividualPatientDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.push(context,
                new MaterialPageRoute(builder: (context) => NewPatients()));
          },
          icon: Icon(
            Icons.keyboard_backspace_rounded,
            size: 35,
            color: Colors.white,
          ),
        ),
        title: Row(
          children: [
            Text(
              "${widget.name}",
              style: TextStyle(
                fontFamily: "OpenSans",
                fontSize: 20.0,
                // fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(width: 30.0),
            Text(
              "${widget.i}i",
              style: TextStyle(
                fontFamily: "OpenSans",
                fontSize: 20.0,
                // fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(width: 30.0),
            Text(
              "Male",
              style: TextStyle(
                fontFamily: "OpenSans",
                fontSize: 20.0,
                // fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        backgroundColor: Color(0xff1957E8),
      ),
      body: Padding(
        padding: EdgeInsets.all(15.0),
        child: Column(
          children: [
            Row(
              children: [
                Column(
                  children: [
                    Text(
                      "Heartbeat/min",
                      style: TextStyle(
                        fontSize: 10.0,
                        fontFamily: "OpenSans",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Text(
                      "75",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 20.0,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 15.0),
                Column(
                  children: [
                    Text(
                      "Pulse Rate",
                      style: TextStyle(
                        fontSize: 10.0,
                        fontFamily: "OpenSans",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Text(
                      "60",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 20.0,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 15.0),
                Column(
                  children: [
                    Text(
                      // "Blood Pressure",
                      "SLNO",
                      style: TextStyle(
                        fontSize: 10.0,
                        fontFamily: "OpenSans",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Text(
                      // "118/88",
                      "${widget.slno}",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 20.0,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 15.0),
                Column(
                  children: [
                    Text(
                      "Body Temp.(°C)",
                      style: TextStyle(
                        fontSize: 10.0,
                        fontFamily: "OpenSans",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Text(
                      "37",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 20.0,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 30.0),
            Row(
              children: [
                Text(
                  "Complaints : ",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontFamily: "OpenSans",
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text(
                    "Pain in the neck, body ache",
                    style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: "Montserrat",
                    ),
                    overflow: TextOverflow.clip,
                  ),
                ),
              ],
            ),
            SizedBox(height: 30.0),
            Row(
              children: [
                Text(
                  "Previous Ailments : ",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontFamily: "OpenSans",
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text("Pain in the neck, body ache",
                      style: TextStyle(
                        fontSize: 15.0,
                        fontFamily: "Montserrat",
                      ),
                      overflow: TextOverflow.clip),
                ),
              ],
            ),
            SizedBox(height: 30.0),
            Row(
              children: [
                Text(
                  "Diagnosed by : ",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontFamily: "OpenSans",
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "Dr. Michael",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontFamily: "Montserrat",
                  ),
                ),
              ],
            ),
            SizedBox(height: 30),
            Row(
              children: [
                Text(
                  "Phone Number : ",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontFamily: "OpenSans",
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text(
                    "9785462230",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 15.0,
                    ),
                    overflow: TextOverflow.clip,
                  ),
                ),
              ],
            ),
            SizedBox(height: 30.0),
            Row(
              children: [
                Text(
                  "Email : ",
                  style: TextStyle(
                    fontFamily: "OpenSans",
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: Text(
                    "helloworld@gmail.com",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 15.0,
                    ),
                    overflow: TextOverflow.clip,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
