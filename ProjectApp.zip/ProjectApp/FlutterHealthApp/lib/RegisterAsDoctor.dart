import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart';
import 'package:tutorial_app/NewOrCheckedPatients.dart';
import 'package:tutorial_app/checkMyData.dart';
import 'loginForm.dart';

class DoctorRegister extends StatefulWidget {
  @override
  _DoctorRegisterState createState() => _DoctorRegisterState();
}

class _DoctorRegisterState extends State<DoctorRegister> {
  var _name,
      _phone,
      _email,
      _password,
      _gender,
      _age,
      _experience,
      _designation;
  String gender = "NULL";
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confpasswordController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final ageController = new TextEditingController();
  final phoneController = new TextEditingController();
  final designationController = new TextEditingController();
  final experienceController = new TextEditingController();
  // final url = "https://jsonplaceholder.typicode.com/users";
  final url = "https://basic-health-app.herokuapp.com/all";
  // final url = "https://basic-health-app.herokuapp.com/docs#/default/EnterRecord_Personal_details____Doctor__put";
  // final url = "https://basic-health-app.herokuapp.com/default/EnterRecord_Personal_details____Doctor__get";
  // final url = "https://basic-health-app.herokuapp.com/docs#/default/EnterRecord_Personal_details____Doctor__get";
  // final url = "https://basic-health-app.herokuapp.com/Personal_details/Kayal?ID=2&Phone=234532532&Email=kayal%40iota.in&Password=kayalmam&Gender=female&Age=35&Experience=5%20years&Designation=MBBS";
  // final url = "https://basic-health-app.herokuapp.com/default/EnterRecord_Personal_details__DoctorName__post";
  // final url = "https://basic-health-app.herokuapp.com/Personal_details//Deepak";

  void postData() async {
    try {
      // final response = await post(Uri.parse(url), body: {
      final response = await post(Uri.parse(url), body: {
        // "title" : "Name",
        // "body" : "Post body",
        // "userId" : "1",
        "Id": "",
        "Name": "",
        "Phone": "",
        "Email": "",
        "Password": "",
        "Gender": "",
        "Age": "",
        "Experience": "",
        "Designation": ""
      });

      print(response.body);
    } catch (err) {}
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(10.0, 50.0, 10.0, 0.0),
            child: Column(children: [
              Container(
                child: Center(
                  child: Text(
                    "Health App",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 28.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 25.0),
              Container(
                child: Center(
                  child: Text(
                    "Fills the form below to register",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 20.0,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 40.0),
              Row(
                children: [
                  Text(
                    "Name : ",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 16.0,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Container(
                    height: 45.0,
                    width: 275.0,
                    padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                    child: TextField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          borderSide: BorderSide(
                            color: Colors.black,
                          ),
                        ),
                        contentPadding:
                            EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                        labelText: "Enter your Name",
                        labelStyle: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: Text(
                        "Phone : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 270.0,
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        controller: phoneController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                          labelText: "Phone Number",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: Text(
                        "Email : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 275.0,
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        controller: _emailController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                          labelText: "Email ID",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: Text(
                        "Password : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 245.0,
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        controller: _passwordController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                          labelText: "Enter password",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 0.0),
                      child: Text(
                        "Age : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 270.0,
                      padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        controller: ageController,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                          labelText: "Enter your age (in yrs)",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: Text(
                        "Gender : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: 100.0,
                            child: ElevatedButton(
                              onPressed: () {
                                gender = "Male";
                              },
                              style: ElevatedButton.styleFrom(
                                primary: Colors.blue[900],
                                shape: new RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(5.0),
                                  side: BorderSide(
                                    color: Colors.blue[900],
                                    width: 1.0,
                                  ),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  "MALE",
                                  style: TextStyle(
                                    fontFamily: "Montserrat",
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: 100.0,
                            child: ElevatedButton(
                              onPressed: () {
                                gender = "Female";
                              },
                              style: ElevatedButton.styleFrom(
                                primary: Colors.blue[900],
                                shape: new RoundedRectangleBorder(
                                  borderRadius: new BorderRadius.circular(5.0),
                                  side: BorderSide(
                                    color: Colors.blue[900],
                                    width: 1.0,
                                  ),
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  "FEMALE",
                                  style: TextStyle(
                                    fontFamily: "Montserrat",
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 20.0, 15.0, 0.0),
                      child: Text(
                        "Experience : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 10.0, 0, 0),
                child: Container(
                  height: 45.0,
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                  child: TextField(
                    controller: experienceController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(5.0)),
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      ),
                      contentPadding: EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 0.0),
                      labelText: "Experience in years",
                      labelStyle: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 16.0,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 20.0, 15.0, 0.0),
                      child: Text(
                        "Designation : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 10.0, 0, 0),
                child: Container(
                  height: 45.0,
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                  child: TextField(
                    controller: designationController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(5.0)),
                        borderSide: BorderSide(
                          color: Colors.black,
                        ),
                      ),
                      contentPadding: EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 0.0),
                      labelText: "Enter your Designation",
                      labelStyle: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 16.0,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 40.0),
              Container(
                height: 50.0,
                width: 250.0,
                child: ElevatedButton(
                  // onPressed: postData,
                  onPressed: () async {
                    if (_formKey.currentState.validate()) {
                      _register();
                    }
                    setState(() {
                      _name = _nameController.text;
                      _age = ageController.text;
                      _gender = gender;
                      _phone = phoneController.text;
                      _email = _emailController.text;
                      _experience = experienceController.text;
                      _designation = designationController.text;
                      // _phone = phoneController.text;
                    });

                    Navigator.push(
                        context,
                        new MaterialPageRoute(
                            builder: (context) => LoginForm()));
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue[900],
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                      side: BorderSide(
                        color: Colors.blue[900],
                        width: 1.0,
                      ),
                    ),
                  ),
                  child: Text(
                    "REGISTER",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 25.0,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
              const Text(
                "Already have an account?",
                style: TextStyle(fontSize: 13),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => CheckMyData()),
                  );
                },
                child: Container(
                    //onPressed: },
                    child: const Text(
                  "SIGN IN NOW",
                  style: TextStyle(color: Color(0xFF03A9F4)),
                )),
              ),
              SizedBox(height: 80, width: 20),
            ]
                // SizedBox(height: 30),
                // Center(
                //   child: Text(
                //     "Name: $_name\n Age: $_age\n Phone:$_phone\n Email:$_email\n Gender: $_gender",
                //     style: TextStyle(
                //       fontFamily: "Montserrat",
                //       fontSize: 16.0,
                //     ),
                //   ),
                // )

                ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _register() async {
    String email = _emailController.text.trim();
    String password = _passwordController.text.trim();
    String confirmpassword = _confpasswordController.text.trim();
    if (password == confirmpassword) {
      try {
        final User user = (await _auth.createUserWithEmailAndPassword(
                email: email, password: password))
            .user;
        setState(() {
          if (user != null) {
            Fluttertoast.showToast(msg: "user created");
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => NewOrCheckedPatients()),
            );
          }
        });
      } catch (e) {
        Fluttertoast.showToast(msg: e.toString());
      }
    } else {
      Fluttertoast.showToast(msg: "Passwords don't match");
    }
  }
}
