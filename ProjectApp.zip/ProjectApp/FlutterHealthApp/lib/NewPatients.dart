import 'dart:convert';
import 'individualPatientDetails.dart';
import 'NewOrCheckedPatients.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

class NewPatients extends StatefulWidget {
  @override
  _NewPatientsState createState() => _NewPatientsState();
}

class _NewPatientsState extends State<NewPatients> {
  final url = "https://basic-health-app.herokuapp.com/all/";
  var _postsJson = [];
  Future<void> fetchPosts() async {
    try {
      final response = await get(Uri.parse(url));
      final jsonData = jsonDecode(response.body) as List;

      setState(() {
        _postsJson = jsonData;
      });
    } catch (err) {
      //
    }
  }
  @override
    void initState() {
      super.initState();
      fetchPosts();
    }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => NewOrCheckedPatients()));
            },
            icon: Icon(
              Icons.keyboard_backspace_rounded,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "New Patients",
            style: TextStyle(
              fontFamily: "OpenSans",
              fontSize: 25.0,
            ),
          ),
          backgroundColor: Color(0xff1957E8),
        ),
        body: ListView.builder(
            itemCount: _postsJson.length,
            itemBuilder: (context, i) {
              final post = _postsJson[i];
              return Card(
                margin: EdgeInsets.all(15.0),
                child: Container(
                  padding: EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Column(
                            children: [
                              Text(
                                "Name",
                                style: TextStyle(
                                  fontFamily: "Raleway",
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "${post["Patient"]}",
                                style: TextStyle(
                                  fontSize: 25.0,
                                  fontFamily: "Montserrat",
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 40.0),
                          Column(
                            children: [
                              Text(
                                "Age",
                                style: TextStyle(
                                  fontFamily: "Montserrat",
                                  fontSize: 10.0,
                                ),
                              ),
                              Text(
                                "${post["Pulse_min"]}",
                                style: TextStyle(
                                  fontSize: 25.0,
                                  fontFamily: "Montserrat",
                                ),
                              ),
                            ],
                          ),
                          SizedBox(width: 40.0),
                          Column(
                            children: [
                              Text(
                                "Gender",
                                style: TextStyle(
                                  fontFamily: "Raleway",
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "Male",
                                style: TextStyle(
                                  fontSize: 25.0,
                                  fontFamily: "Montserrat",
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                        ],
                      ),
                      SizedBox(height: 30.0),
                      Row(
                        children: [
                          Text(
                            "Complaints : ",
                            style: TextStyle(
                              fontSize: 15.0,
                              fontFamily: "OpenSans",
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              "Severe pain in the neck Severe pain in the neck",
                              style: TextStyle(
                                fontSize: 15.0,
                                fontFamily: "Montserrat",
                              ),
                              overflow: TextOverflow.clip,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 30.0),
                      Row(
                        children: [
                          Text(
                            "Previous ailments : ",
                            style: TextStyle(
                              fontSize: 15.0,
                              fontFamily: "OpenSans",
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Lorem ipsum",
                            style: TextStyle(
                              fontSize: 15.0,
                              fontFamily: "Montserrat",
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 30.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              primary: Color(0xff1957E8),
                            ),
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  new MaterialPageRoute(
                                      builder: (context) => IndividualPatientDetails()));
                            },
                            child: Text(
                              "View Card",
                              style: TextStyle(
                                fontFamily: "Raleway",
                                fontSize: 20.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }),
      ),
    );
  }
}
