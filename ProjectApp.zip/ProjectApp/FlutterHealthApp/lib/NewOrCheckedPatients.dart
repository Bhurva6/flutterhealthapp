import "package:flutter/material.dart";
import 'package:tutorial_app/loginForm.dart';
import 'package:tutorial_app/userProfileDoctor.dart';
import 'NewPatients.dart';

class NewOrCheckedPatients extends StatelessWidget {
  const NewOrCheckedPatients({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.push(context,
                new MaterialPageRoute(builder: (context) => LoginForm()));
          },
          icon: Icon(
            Icons.keyboard_backspace,
            size: 35,
            color: Colors.white,
          ),
        ),
        title: Text(
          "Health App",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 23.0,
            fontWeight: FontWeight.w500,
          ),
        ),
        backgroundColor: Color(0xff1957E8),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(0, 150, 0, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(300.0, 50.0),
                        primary: Color(0xff1957E8),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => NewPatients()));
                      },
                      icon: Icon(
                        Icons.arrow_right,
                        size: 30,
                      ),
                      label: Text(
                        // "Button 1",
                        "New Patients",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                        ),
                      ),
                    ),
                    SizedBox(height: 30),
                    ElevatedButton.icon(
                      
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(300.0, 50.0),
                        primary: Color(0xff1957E8),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => NewPatients()));
                      },
                      icon: Icon(
                        Icons.arrow_right,
                        size: 30,
                      ),
                      label: Text(
                        // "Button 2",
                        "Checked Patients",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(0, 230.0, 0, 0),
            child: Container(
              height: 50.0,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width*0.45,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => UserProfile()));
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xff1957E8),
                      ),
                      child: Center(
                        child: Text(
                          // "Button 3",
                          "Profile",
                          style: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 1.0),
                  Container(
                    width: MediaQuery.of(context).size.width*0.45,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            new MaterialPageRoute(
                                builder: (context) => LoginForm()));
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xff1957E8),
                      ),
                      child: Center(
                        child: Text(
                          // "Button 4",
                          "Logout",
                          style: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
