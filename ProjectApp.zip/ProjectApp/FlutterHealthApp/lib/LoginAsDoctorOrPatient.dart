import 'package:flutter/material.dart';
import 'package:tutorial_app/NewOrCheckedPatients.dart';
import 'package:tutorial_app/ConsultDoctorOrCheckMyData.dart';
// import 'package:tutorial_app/loginForm.dart';

class DPNavigator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Padding(
          padding: EdgeInsets.fromLTRB(10.0, 50.0, 10.0, 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "This page is only for testing purpose, it won't be there on original app",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: "Montserrat",
                  fontSize: 20.0,
                ),
              ),
              SizedBox(
                height: 40.0,
              ),
              Container(
                // width: 250.0,
                height: 50.0,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        new MaterialPageRoute(builder: (context) => NewOrCheckedPatients()));
                  },
                  child: Center(
                    child: Text(
                      "Doctors",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 20.0,
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 50.0),
              Container(
                height: 50.0,
                // width: 250.0,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        new MaterialPageRoute(builder: (context) => PatientSide1()));
                  },
                  child: Center(
                    child: Text(
                      "Patients",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 20.0,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
