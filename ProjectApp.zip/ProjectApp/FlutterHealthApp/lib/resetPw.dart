import 'package:flutter/material.dart';
import 'package:tutorial_app/newPw.dart';
import 'loginForm.dart';

class Otp extends StatelessWidget {
  // const Otp({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => ResetPw()));
            },
            icon: Icon(
              Icons.keyboard_backspace,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "Reset Password",
            style: TextStyle(
              fontFamily: "OpenSans",
              fontSize: 20.0,
            ),
          ),
          backgroundColor: Color(0xff1957E8),
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    borderSide: BorderSide(
                      color: Colors.black,
                    ),
                  ),
                  contentPadding: EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                  labelText: "Enter OTP",
                  labelStyle: TextStyle(
                    fontFamily: "Montserrat",
                    fontSize: 20.0,
                  ),
                ),
              ),
              SizedBox(height: 30.0),
              Container(
                height: 50.0,
                width: 325.0,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        new MaterialPageRoute(builder: (context) => NewPwd()));
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue[900],
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                    ),
                  ),
                  child: Text(
                    "Reset Password",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 25.0,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ResetPw extends StatelessWidget {
  // const ResetPw({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => LoginForm()));
            },
            icon: Icon(
              Icons.keyboard_backspace,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "Reset Password",
            style: TextStyle(
              fontFamily: "OpenSans",
              fontSize: 20.0,
            ),
          ),
          backgroundColor: Color(0xff1957E8),
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    borderSide: BorderSide(
                      color: Colors.black,
                    ),
                  ),
                  contentPadding: EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                  labelText: "Enter registered E-mail Id",
                  labelStyle: TextStyle(
                    fontFamily: "Montserrat",
                    fontSize: 20.0,
                  ),
                ),
              ),
              SizedBox(height: 30.0),
              Container(
                height: 50.0,
                width: 325.0,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        new MaterialPageRoute(builder: (context) => Otp()));
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Colors.blue[900],
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(30.0),
                    ),
                  ),
                  child: Text(
                    "Send OTP",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 25.0,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
