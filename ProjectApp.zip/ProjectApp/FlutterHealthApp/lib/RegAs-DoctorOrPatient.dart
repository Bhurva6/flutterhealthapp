import 'package:flutter/material.dart';
import 'package:tutorial_app/RegisterAsDoctor.dart';
import 'package:tutorial_app/RegisterAsPatient.dart';

class DoctorOrPatient extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Text(
                "Register as : ",
                style: TextStyle(
                  fontFamily: "Montserrat",
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 50.0),
            Container(
              height: 50.0,
              width: 300.0,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => DoctorRegister()));
                },
                style: ElevatedButton.styleFrom(
                  elevation: 10.0,
                  primary: Color(0xff1957e8),
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(30.0),
                  ),
                ),
                child: Center(
                  child: Text(
                    "Doctor",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 20.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.0),
            Container(
              height: 50.0,
              width: 300.0,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => RegisterForm()));
                },
                style: ElevatedButton.styleFrom(
                  elevation: 10.0,
                  primary: Color(0xff1957e8),
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(30.0),
                  ),
                ),
                child: Center(
                  child: Text(
                    "Patient",
                    style: TextStyle(
                      fontFamily: "Montserrat",
                      fontSize: 20.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
