import 'package:flutter/material.dart';
import 'ConsultDoctorOrCheckMyData.dart';

class UserProfilePatient extends StatefulWidget {
  @override
  _UserProfilePatientState createState() => _UserProfilePatientState();
}

class _UserProfilePatientState extends State<UserProfilePatient> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => PatientSide1()));
            },
            icon: Icon(
              Icons.keyboard_backspace,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "My Profile",
            style: TextStyle(
              fontFamily: "OpenSans",
              fontSize: 20.0,
            ),
          ),
          backgroundColor: Color(0xffe81981),
        ),
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.fromLTRB(10.0, 20.0, 0, 0),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(0, 30.0, 0.0, 0.0),
                  // height: 40.0,
                  child: Center(
                    child: Text(
                      "Health App",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 28.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25.0),
                Container(
                  // height: 40.0,
                  child: Center(
                    child: Text(
                      "Update your profile : ",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 20.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20.0),
                Row(
                  children: [
                    Text(
                      "Name : ",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 20.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 250.0,
                      // padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
                          labelText: "Jane Doe",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10.0),
                Row(
                  children: [
                    Text(
                      "Age : ",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 20.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 100.0,
                      padding: EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
                          labelText: "25 Yrs",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(10.0, 0, 0, 0),
                      child: Row(
                        children: [
                          Text(
                            "Gender : ",
                            style: TextStyle(
                              fontFamily: "Montserrat",
                              fontSize: 20.0,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Container(
                            height: 45.0,
                            width: 70.0,
                            padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                            child: TextField(
                              textAlign: TextAlign.center,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5.0)),
                                  borderSide: BorderSide(
                                    color: Colors.black,
                                  ),
                                ),
                                contentPadding:
                                    EdgeInsets.fromLTRB(10.0, 10.0, 0.0, 0.0),
                                labelText: "FM",
                                labelStyle: TextStyle(
                                  fontFamily: "Montserrat",
                                  fontSize: 20.0,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10.0),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: Text(
                        "Phone : ",
                        style: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Container(
                      height: 45.0,
                      width: 245.0,
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            borderSide: BorderSide(
                              color: Colors.black,
                            ),
                          ),
                          contentPadding:
                              EdgeInsets.fromLTRB(4.0, 10.0, 0.0, 0.0),
                          labelText: "Phone Number",
                          labelStyle: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                  child: Row(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(0.0, 10.0, 15.0, 0.0),
                        child: Text(
                          "Complaints : ",
                          style: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0, 10.0, 20, 0),
                  child: Container(
                    height: 45.0,
                    // width: 250.0,
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          borderSide: BorderSide(
                            color: Colors.black,
                          ),
                        ),
                        contentPadding:
                            EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 0.0),
                        labelText: "Enter your complaint",
                        labelStyle: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0, 10.0, 20, 0),
                  child: Container(
                    height: 45.0,
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          borderSide: BorderSide(
                            color: Colors.black,
                          ),
                        ),
                        contentPadding:
                            EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 0.0),
                        labelText: "Enter your complaint",
                        labelStyle: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10.0),
                Padding(
                  padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                  child: Row(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(0.0, 10.0, 15.0, 0.0),
                        child: Text(
                          "Previous Ailment consulter by : ",
                          style: TextStyle(
                            fontFamily: "Montserrat",
                            fontSize: 20.0,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0, 10.0, 20, 0),
                  child: Container(
                    height: 45.0,
                    // width: 250.0,
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                    child: TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5.0)),
                          borderSide: BorderSide(
                            color: Colors.black,
                          ),
                        ),
                        contentPadding:
                            EdgeInsets.fromLTRB(5.0, 10.0, 0.0, 0.0),
                        labelText: "Enter doctor's name",
                        labelStyle: TextStyle(
                          fontFamily: "Montserrat",
                          fontSize: 20.0,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 30.0),
                Container(
                  height: 50.0,
                  width: 250.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          new MaterialPageRoute(
                              builder: (context) => PatientSide1()));
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Color(0xffe81981),
                      shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(30.0),
                        side: BorderSide(
                          color: Color(0xffe81981),
                          width: 1.0,
                        ),
                      ),
                    ),
                    child: Text(
                      "SAVE",
                      style: TextStyle(
                        fontFamily: "Montserrat",
                        fontSize: 25.0,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
