import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tutorial_app/NewOrCheckedPatients.dart';
import 'package:tutorial_app/RegAs-DoctorOrPatient.dart';
import 'package:tutorial_app/LoginAsDoctorOrPatient.dart';
import 'package:tutorial_app/resetPw.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            child: Center(
              child: Text(
                "Login into Health App",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: "Montserrat",
                  fontSize: 25.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(height: 40.0),
          Container(
            padding: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
            child: Center(
              child: TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: "Email",
                  labelStyle: TextStyle(
                    fontFamily: "Montserrat",
                    fontWeight: FontWeight.w400,
                    fontSize: 18.0,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 10.0),
          Container(
            padding: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 0.0),
            child: Center(
              child: TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: "Password",
                  labelStyle: TextStyle(
                    fontFamily: "Montserrat",
                    fontWeight: FontWeight.w400,
                    fontSize: 18.0,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 50.0),
          Container(
            height: 50.0,
            width: 325.0,
            child: ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState.validate()) {
                  setState(() {
                    _signInWithEmailAndPassword();
                  });
                }
              },
              style: ElevatedButton.styleFrom(
                primary: Color(0xff1957E8),
                shape: new RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(30.0),
                ),
              ),
              child: Text(
                "LOGIN",
                style: TextStyle(
                    fontFamily: "Montserrat",
                    fontSize: 25.0,
                    fontWeight: FontWeight.w500),
              ),
            ),
          ),
          SizedBox(height: 20.0),
          Container(
            height: 50.0,
            width: 325.0,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => DoctorOrPatient()),
                  );
                });
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.white70,
                shape: new RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(30.0),
                  side: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              ),
              child: Text(
                "REGISTER",
                style: TextStyle(
                  fontFamily: "Montserrat",
                  fontSize: 25.0,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => ResetPw()),
                    );
                  });
                },
                child: Container(
                    margin: EdgeInsets.only(top: 20, left: 150),
                    child: const Text(
                      "Forgot Passsword?",
                      style: TextStyle(fontSize: 13, color: Color(0xFF03A9F4)),
                    )),
              ),
            ],
          ),
        ]),
      ),
    );
  }

  _signInWithEmailAndPassword() async {
    try {
      final User user = (await _firebaseAuth.signInWithEmailAndPassword(
              email: _emailController.text.trim(),
              password: _passwordController.text.trim()))
          .user;
      if (user != null) {
        setState(() {
          Fluttertoast.showToast(msg: "Signed In Sucessfully");
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => NewOrCheckedPatients()),
          );
        });
      }
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }
}
