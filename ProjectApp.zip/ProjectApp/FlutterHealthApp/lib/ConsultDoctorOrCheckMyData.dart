import 'package:flutter/material.dart';
import 'package:tutorial_app/checkMyData.dart';
import 'package:tutorial_app/consultDoctor.dart';
import 'package:tutorial_app/UserProfilePatient.dart';

import 'loginForm.dart';

class PatientSide1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => LoginForm()));
            },
            icon: Icon(
              Icons.keyboard_backspace,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "Health App",
            style: TextStyle(
              fontFamily: "Montserrat",
              fontSize: 25.0,
              fontWeight: FontWeight.w500,
            ),
          ),
          backgroundColor: Color(0xffe81981),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(0, 150, 0, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size(300.0, 50.0),
                          primary: Color(0xffe81981),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => ConsultDoctor()));
                        },
                        icon: Icon(
                          Icons.arrow_right,
                          size: 30,
                        ),
                        label: Text(
                          "Consult doctor",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontFamily: "Raleway",
                            fontSize: 30.0,
                          ),
                        ),
                      ),
                      SizedBox(height: 30),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size(300.0, 50.0),
                          primary: Color(0xffe81981),
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => CheckMyData()));
                        },
                        icon: Icon(
                          Icons.arrow_right,
                          size: 30,
                        ),
                        label: Text(
                          "Check my data",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontFamily: "Raleway",
                            fontSize: 30.0,
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 230.0, 0, 0),
              child: Container(
                height: 50.0,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.45,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => UserProfilePatient()));
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xffe81981),
                        ),
                        child: Center(
                          child: Text(
                            "Profile",
                            style: TextStyle(
                              fontFamily: "Montserrat",
                              fontSize: 20.0,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 1.0),
                    Container(
                      width: MediaQuery.of(context).size.width*0.45,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              new MaterialPageRoute(
                                  builder: (context) => LoginForm()));
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Color(0xffe81981),
                        ),
                        child: Center(
                          child: Text(
                            "Logout",
                            style: TextStyle(
                              fontFamily: "Montserrat",
                              fontSize: 20.0,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
