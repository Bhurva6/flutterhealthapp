import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tutorial_app/ConsultDoctorOrCheckMyData.dart';


class DoctorList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        padding: EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    Text(
                      "Name",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 10.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Dr.Michael",
                      style: TextStyle(
                        fontSize: 20.0,
                        fontFamily: "Raleway",
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 40.0),
                Column(
                  children: [
                    Text(
                      "Age",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 10.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "65yrs",
                      style: TextStyle(
                        fontSize: 20.0,
                        fontFamily: "Montserrat",
                      ),
                    ),
                  ],
                ),
                SizedBox(width: 40.0),
              ],
            ),
            SizedBox(height: 30.0),
            Padding(
              padding: EdgeInsets.fromLTRB(20.0, 0, 0, 0),
              child: Row(
                children: [
                  Text(
                    "Experience : ",
                    style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: "OpenSans",
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      "28yrs",
                      style: TextStyle(
                        fontSize: 15.0,
                        fontFamily: "Raleway",
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30.0),
            Padding(
              padding: EdgeInsets.fromLTRB(20.0, 0, 0, 0),
              child: Row(
                children: [
                  Text(
                    "Designation : ",
                    style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: "OpenSans",
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "M.B.B.S",
                    style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: "OpenSans",
                      // fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30.0),
            Padding(
              padding: EdgeInsets.fromLTRB(20.0, 0, 0, 0),
              child: Row(
                children: [
                  Text(
                    "Phone No. : ",
                    style: TextStyle(
                      fontFamily: "OpenSans",
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    "9874560231",
                    style: TextStyle(
                      fontFamily: "OpenSans",
                      fontSize: 15.0,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30.0),
            Padding(
              padding: EdgeInsets.fromLTRB(20.0, 0, 0, 0),
              child: Row(
                children: [
                  Text(
                    "Mail Id : ",
                    style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold),
                  ),
                  Expanded(
                    child: Text(
                      "MaiMaaikalHoon@gmail.com",
                      style: TextStyle(
                        fontFamily: "OpenSans",
                        fontSize: 15.0,
                      ),
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ConsultDoctor extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.push(context,
                  new MaterialPageRoute(builder: (context) => PatientSide1()));
            },
            icon: Icon(
              Icons.keyboard_backspace,
              size: 35,
              color: Colors.white,
            ),
          ),
          title: Text(
            "Health App",
            style: TextStyle(
              fontFamily: "Montserrat",
              fontSize: 25.0,
              fontWeight: FontWeight.w500,
            ),
          ),
          backgroundColor: Color(0xffe81981),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(10.0),
            child: Column(
              children: [
                DoctorList(),
                SizedBox(height: 10.0),
                DoctorList(),
                SizedBox(height: 10.0),
                DoctorList(),
                SizedBox(height: 10.0),
                DoctorList(),
                SizedBox(height: 10.0),
                DoctorList(),
                SizedBox(height: 10.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
