# FlutterHealthApp

## Please Note : 
- Do not commit/modify anything on the main branch.
- If you are to make any changes, then pls make a branch *(Branch name should be your name)* and make all the changes to your branch **ONLY**.
- Do not make multiple branches for the same person.
- If possible pls add a short commit message to all your commits about the recent changes that you have made.

### Thank You :)
